import EnrolmentForm from "./components/EnrolmentForm";

function App(){
  return(
    <>
      <EnrolmentForm/>
    </>
  )
}
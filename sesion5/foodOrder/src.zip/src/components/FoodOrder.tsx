import { FormEvent, MouseEventHandler, useEffect, useState } from "react";
import { MenuItem } from "../entities/entities";

interface FoodOrderProps {
    food: MenuItem;
    onQuantityUpdated(id: number, quantity: number): void;
    onReturnToMenu: MouseEventHandler<HTMLButtonElement> | undefined;
}
function FoodOrder(props: FoodOrderProps) {
    //**  Estados para nombre, cantidad y número de teléfono
    const [firstName, setFirstName] = useState("");
    const [quantity, setQuantity] = useState("");
    const [phone, setPhone] = useState("");
    const [welcomeMessage, setWelcomeMessage] = useState("");


    useEffect(() => {

    }, [props.onQuantityUpdated])

    const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
        const submitter = (event.nativeEvent as SubmitEvent).submitter as HTMLInputElement;

        setWelcomeMessage(`Pedido enviado, recibirá un SMS una vez esté listo para recoger`);
        /*props.onQuantityUpdated();

        const foodOrder: MenuItem = {
            id: ,
            name: ,
            quantity: ,
        }*/
    };


    return (
        <div>
            <form onSubmit={handleSubmit}>
                <h2>Comida rápida online</h2>

                <input
                    type="text"
                    name="lname"
                    onChange={(event) => setPhone(event.target.value)}
                    value={phone}
                />
                
                <input
                    type="text"
                    name="fname"
                    onChange={(event) => setFirstName(event.target.value)}

                    value={firstName}
                />

                <input
                    type="text"
                    name="lname"
                    onChange={(event) => setPhone(event.target.value)}
                    value={phone}
                />

                <input type="submit" value="Enviar pedido" className="submitButton" />
                <input type="submit" value="Volver al menú" className="submitButton" />

                <label id="correctMsg" className="message">
                    {welcomeMessage}
                </label>
            </form>
        </div>
    )
}

export default FoodOrder;